package decok.dfcdvadstf.catframe.model.state.item;

import decok.dfcdvadstf.catframe.model.BlockJsonModelBake.BakedQuad;
import decok.dfcdvadstf.catframe.model.IItemStateProvider;
import decok.dfcdvadstf.catframe.model.core.ModelJson;
import decok.dfcdvadstf.catframe.model.render.RenderPhase;
import decok.dfcdvadstf.catframe.model.render.UniformRenderPipeline;
import decok.dfcdvadstf.catframe.model.state.BlockStateModel;
import decok.dfcdvadstf.catframe.model.state.BlockStateModelPart;
import decok.dfcdvadstf.catframe.model.state.block.SingleBlockModel;
import net.minecraft.item.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * 方块状态物品模型包装器。
 * <p>
 * 将 {@link BlockStateModel} 的烘焙 quads 复用为物品渲染，
 * 类似于 1.21.5 的 CuboidItemModelWrapper。
 * <p>
 * 物品渲染时，通过 {@link UniformRenderPipeline#renderItemQuads} 完成
 * 扩展链处理和 Tessellator 提交。
 * <p>
 * 支持 JSON model 的 {@code display} transforms，根据 {@link RenderPhase}
 * 自动应用对应的变换（gui / thirdperson_righthand）。
 */
public class BlockStateItemState implements IItemStateProvider {

    private final BlockStateModel blockModel;
    private final Map<String, ModelJson.DisplayTransform> display;

    public BlockStateItemState(BlockStateModel blockModel) {
        this(blockModel, null);
    }

    public BlockStateItemState(BlockStateModel blockModel, Map<String, ModelJson.DisplayTransform> display) {
        this.blockModel = blockModel;
        this.display = display;
    }

    public BlockStateItemState(BlockStateModelPart part) {
        this(part, null);
    }

    public BlockStateItemState(BlockStateModelPart part, Map<String, ModelJson.DisplayTransform> display) {
        this.blockModel = new SingleBlockModel(part);
        this.display = display;
    }

    /**
     * 从预烘焙的 quad 列表直接构造（无需经过 BlockStateModel 调度）。
     */
    public static BlockStateItemState fromQuads(List<BakedQuad> quads) {
        return new BlockStateItemState(BlockStateModelPart.fromQuads(quads));
    }

    public static BlockStateItemState fromQuads(List<BakedQuad> quads, Map<String, ModelJson.DisplayTransform> display) {
        return new BlockStateItemState(BlockStateModelPart.fromQuads(quads), display);
    }

    @Override
    public void render(ItemStack stack, RenderPhase phase) {
        // 物品渲染不需要世界坐标，metadata 来自栈 damage
        int damage = stack.getItemDamage();
        BlockStateModelPart part = blockModel.collectParts(null, 0, 0, 0, damage);
        if (part == null || part.isEmpty()) return;

        UniformRenderPipeline.renderItemQuads(part, stack, phase, display);
    }
}
