package decok.dfcdvadstf.catframe.model;

import decok.dfcdvadstf.catframe.CatFrame;
import decok.dfcdvadstf.catframe.core.Direction;
import decok.dfcdvadstf.catframe.model.core.AtlasPixelCache;
import decok.dfcdvadstf.catframe.model.core.baking.JsonModelBake;
import decok.dfcdvadstf.catframe.resources.atlas.CatSprite;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.IIcon;

import javax.vecmath.Vector3d;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 物品模型侧面生成器 —— 对标 26.1.2 {@code ItemModelGenerator.bakeSideFaces}。
 * <p>
 * 逐像素扫描纹理，在“不透明→透明”的交界处生成 1px 宽的侧面 quad，
 * 让 2D 物品的挤出厚度侧面拥有与边缘像素一致的颜色。
 * <p>
 * 与 ModelResolver 中 builtin/generated 的 from/to (7.5→8.5) 一致：
 * 侧面 quad 的 Z 范围为 {@code MIN_Z/16 ~ MAX_Z/16}（block 空间）。
 */
public class ItemModelGenerator {

    /** Z 轴挤出范围（像素空间），与 ModelResolver 中 builtin/generated 的 from/to 一致 */
    static final float MIN_Z = 7.5F;
    static final float MAX_Z = 8.5F;

    /**
     * UV 内缩量（像素空间），对标 26.1.2 ItemModelGenerator.UV_SHRINK。
     * 侧面 quad 的 UV 从像素边界各缩进 0.1 像素，避免图集接缝处的相邻像素闪烁。
     */
    private static final float UV_SHRINK = 0.1F;

    /**
     * 为一个图层纹理生成侧面 quad。
     * <p>
     * 扫描网格与坐标比例以 AtlasPixelCache 的内容切片（UV 区域）为准，
     * 不信任 {@code getIconWidth()}：各向异性过滤时 1.7.10 原版会把物理存储
     * 扩为 (内容+16)x(内容+16) 并让 getIconWidth() 返回该填充尺寸。
     *
     * @param icon      图层纹理 sprite
     * @param tintIndex 染色索引（多层模型时对应 layerN），-1 表示无染色
     * @return 侧面 BakedQuad 列表
     */
    public static List<JsonModelBake.BakedQuad> bakeSideFaces(IIcon icon, int tintIndex) {
        List<JsonModelBake.BakedQuad> quads = new ArrayList<>();

        // 像素源双分支：自定义图集 sprite（CatSprite）直接读 CPU 自有像素；
        // 原版 sprite 走 AtlasPixelCache 的 UV 区域内容切片。两者均为内容尺寸网格。
        // Pixel source: CatSprite reads its CPU-owned pixels directly; vanilla
        // sprites use the AtlasPixelCache UV-region content slice. Both grids
        // are content-sized.
        int[] flatPixels;
        int width, height;
        if (icon instanceof CatSprite) {
            CatSprite catSprite = (CatSprite) icon;
            flatPixels = catSprite.getPixels();
            width = catSprite.getIconWidth();
            height = catSprite.getIconHeight();
        } else if (icon instanceof TextureAtlasSprite) {
            TextureAtlasSprite sprite = (TextureAtlasSprite) icon;

            // 扫描网格以内容切片为准（AtlasPixelCache 按 sprite 的 UV 区域裁剪）：
            // 开启各向异性过滤时 1.7.10 原版把物理存储扩为 (内容+16)x(内容+16)，
            // getIconWidth() 返回物理存储尺寸（含填充边框），不能作为内容网格。
            // Grid/scale are driven by the UV-region content slice, not by
            // getIconWidth(), which reports the padded storage size under
            // anisotropic filtering.
            AtlasPixelCache.CachedSprite cached = AtlasPixelCache.getSprite(sprite.getIconName());
            if (cached == null || cached.pixels.length < cached.width * cached.height) {
                CatFrame.logger.debug("[ItemModelGenerator] no pixel data for sprite '{}'", sprite.getIconName());
                return quads;
            }
            flatPixels = cached.pixels;
            width = cached.width;
            height = cached.height;
        } else {
            return quads;
        }

        float xScale = 16.0F / width;
        float yScale = 16.0F / height;

        // 使用 Set 去重：同一像素的同一方向只生成一次（多帧扫描时重复）
        Set<String> emitted = new HashSet<>();

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (isTransparent(flatPixels, x, y, width)) {
                    continue;
                }

                // 读取当前不透明像素的 ARGB 颜色，用于侧面纯色填充
                int pixelARGB = flatPixels[y * width + x];

                // 上边：上方像素透明 → 生成 UP 面 quad
                if (isTransparent(flatPixels, x, y - 1, width)) {
                    String key = "U" + x + "," + y;
                    if (emitted.add(key)) {
                        bakeHorizontalEdge(quads, icon, x, y, true, xScale, yScale, tintIndex, pixelARGB);
                    }
                }
                // 下边：下方像素透明 → 生成 DOWN 面 quad
                if (isTransparent(flatPixels, x, y + 1, width)) {
                    String key = "D" + x + "," + y;
                    if (emitted.add(key)) {
                        bakeHorizontalEdge(quads, icon, x, y, false, xScale, yScale, tintIndex, pixelARGB);
                    }
                }
                // 左边：左侧像素透明 → 生成 WEST 面 quad（朝外绕序，见 bakeVerticalEdge 说明）
                if (isTransparent(flatPixels, x - 1, y, width)) {
                    String key = "L" + x + "," + y;
                    if (emitted.add(key)) {
                        bakeVerticalEdge(quads, icon, x, y, true, xScale, yScale, tintIndex, pixelARGB);
                    }
                }
                // 右边：右侧像素透明 → 生成 EAST 面 quad（朝外绕序，见 bakeVerticalEdge 说明）
                if (isTransparent(flatPixels, x + 1, y, width)) {
                    String key = "R" + x + "," + y;
                    if (emitted.add(key)) {
                        bakeVerticalEdge(quads, icon, x, y, false, xScale, yScale, tintIndex, pixelARGB);
                    }
                }
            }
        }

        CatFrame.logger.info(
                "[ItemModelGenerator] sprite '{}' content {}x{} (phys {}x{}): {} edge pixels → {} side quads",
                icon.getIconName(), width, height, icon.getIconWidth(), icon.getIconHeight(), emitted.size(),
                quads.size());

        return quads;
    }

    /**
     * 生成水平边缘（上/下）的侧面 quad —— 对标 BlockJsonModelBake.emitFaceFromCorners 的绕序规范。
     * <p>
     * quad 是 XZ 平面上的平片：宽 = 1px，深 = 1px（Z: 7.5→8.5）。
     * UP 和 DOWN 使用不同的顶点绕序以产生正确的法线方向。
     */
    private static void bakeHorizontalEdge(
            List<JsonModelBake.BakedQuad> quads,
            IIcon sprite,
            int x, int y, boolean isTop,
            float xScale, float yScale, int tintIndex, int pixelARGB) {

        // 世界坐标（block 空间 0-1）
        float worldX0 = (x * xScale) / 16.0F;
        float worldX1 = ((x + 1.0F) * xScale) / 16.0F;

        // Y: 逐像素定位
        // 纹理 y=0 是顶部 → 世界 Y=1；y=height 是底部 → 世界 Y=0
        float worldY;
        if (isTop) {
            // UP = 像素上边缘
            worldY = (16.0F - y * yScale) / 16.0F;
        } else {
            // DOWN = 像素下边缘
            worldY = (16.0F - (y + 1.0F) * yScale) / 16.0F;
        }

        // UV（像素空间）—— 对标 26.1.2：u0/u1 为像素左右边界 + UV_SHRINK，
        // v0/v1 因方向不同：水平面(UP/DOWN) V 轴反转（v0=bottom, v1=top），
        // 垂直面(EAST/WEST) V 轴正常（v0=top, v1=bottom）。
        float u0 = (x + UV_SHRINK) * xScale;
        float u1 = (x + 1.0F - UV_SHRINK) * xScale;
        float v0, v1;
        if (isTop) {
            // UP: V 反转 —— v0 对应像素底部（worldY 侧），v1 对应像素顶部
            v0 = (y + 1.0F - UV_SHRINK) * yScale;
            v1 = (y + UV_SHRINK) * yScale;
        } else {
            // DOWN: V 正常 —— v0=像素顶部, v1=像素底部
            v0 = (y + UV_SHRINK) * yScale;
            v1 = (y + 1.0F - UV_SHRINK) * yScale;
        }

        Direction face = isTop ? Direction.UP : Direction.DOWN;

        JsonModelBake.BakedQuad q = new JsonModelBake.BakedQuad();
        q.icon = sprite;
        q.face = face;
        q.tintIndex = tintIndex;
        q.guiLight = "front";
        // Force opaque alpha: side faces are solid-color filled in a second untextured
        // pass
        // 侧面强制不透明：由第二遍无纹理渲染以纯色填充，避免半透明纹素被 blend 冲淡
        q.solidColor = pixelARGB | 0xFF000000;

        // 顶点绕序：对标 BlockJsonModelBake.emitFaceFromCorners
        // UP: v0(idx=010)=MIN_X,MIN_Z v1(idx=011)=MIN_X,MAX_Z v2(idx=111)=MAX_X,MAX_Z
        // v3(idx=110)=MAX_X,MIN_Z
        // DOWN:v0(idx=001)=MIN_X,MAX_Z v1(idx=000)=MIN_X,MIN_Z v2(idx=100)=MAX_X,MIN_Z
        // v3(idx=101)=MAX_X,MAX_Z
        float minZ = MIN_Z / 16.0F, maxZ = MAX_Z / 16.0F;
        if (isTop) {
            q.vertices[0] = new Vector3d(worldX0, worldY, minZ);
            q.vertices[1] = new Vector3d(worldX0, worldY, maxZ);
            q.vertices[2] = new Vector3d(worldX1, worldY, maxZ);
            q.vertices[3] = new Vector3d(worldX1, worldY, minZ);
        } else {
            q.vertices[0] = new Vector3d(worldX0, worldY, maxZ);
            q.vertices[1] = new Vector3d(worldX0, worldY, minZ);
            q.vertices[2] = new Vector3d(worldX1, worldY, minZ);
            q.vertices[3] = new Vector3d(worldX1, worldY, maxZ);
        }
        // UV 按顶点分配：v0→MIN_Z 顶点, v1→MAX_Z 顶点；u0→MIN_X, u1→MAX_X
        q.up[0] = u0;
        q.vp[0] = v0;
        q.up[1] = u0;
        q.vp[1] = v1;
        q.up[2] = u1;
        q.vp[2] = v1;
        q.up[3] = u1;
        q.vp[3] = v0;

        q.faceNormal = faceNormal(face);
        quads.add(q);
    }

    /**
     * 生成垂直边缘（左/右）的侧面 quad —— 对标 BlockJsonModelBake.emitFaceFromCorners 的绕序规范。
     * <p>
     * quad 是 YZ 平面上的平片：高 = 1px，深 = 1px（Z: 7.5→8.5）。
     * <p>
     * 方向映射（刻意偏离 26.1.2 的 LEFT→EAST / RIGHT→WEST）：
     * LEFT → Direction.WEST (法线 -X，朝向左侧透明像素，从左边可见)
     * RIGHT → Direction.EAST (法线 +X，朝向右侧透明像素，从右边可见)
     * <p>
     * 原版 26.1.2 让东西侧面朝向像素<b>内侧</b>（LEFT→EAST），可见性依赖
     * cutout 丢弃透明纹素后"从对侧透视看到远端条带"的机制；CatFrame 固定管线
     * 开启背面剔除且无该 cutout 深度语义，朝内绕序会被整面剔除（表现为东西面
     * 挤出透明消失）。故此处改为<b>朝外</b>绕序，与 UP/DOWN 的朝外约定对齐，
     * 剔除语义等同实心几何体。
     * Deliberate deviation from vanilla: vertical side faces wind OUTWARD
     * (towards the transparent neighbour) so they survive backface culling
     * in the 1.7.10 fixed pipeline, matching the UP/DOWN convention.
     */
    private static void bakeVerticalEdge(
            List<JsonModelBake.BakedQuad> quads,
            IIcon sprite,
            int x, int y, boolean isLeft,
            float xScale, float yScale, int tintIndex, int pixelARGB) {

        // 世界坐标（block 空间 0-1）—— 对标 26.1.2：
        // LEFT 边在像素左边界 (x * xScale)，RIGHT 边在像素右边界 ((x+1) * xScale)
        float worldX = isLeft
                ? (x * xScale) / 16.0F
                : ((x + 1.0F) * xScale) / 16.0F;

        // Y: 像素 y → block 空间（Y 翻转：纹理上方 → 世界上方）
        float worldY0 = (16.0F - (y + 1.0F) * yScale) / 16.0F;
        float worldY1 = (16.0F - y * yScale) / 16.0F;

        // UV（像素空间）—— 对标 26.1.2：u0/u1 为像素左右边界 + UV_SHRINK（沿 Z 轴跨越挤出深度），
        // v0/v1 为像素上下边界 + UV_SHRINK（沿世界 Y 轴分配：v0=top, v1=bottom）
        float u0 = (x + UV_SHRINK) * xScale;
        float u1 = (x + 1.0F - UV_SHRINK) * xScale;
        float v0 = (y + UV_SHRINK) * yScale;
        float v1 = (y + 1.0F - UV_SHRINK) * yScale;

        // 朝外绕序：LEFT→WEST（-X）, RIGHT→EAST（+X），偏离 26.1.2（理由见方法 JavaDoc）
        // Outward-facing: LEFT→WEST, RIGHT→EAST (see method JavaDoc for rationale)
        Direction face = isLeft ? Direction.WEST : Direction.EAST;

        JsonModelBake.BakedQuad q = new JsonModelBake.BakedQuad();
        q.icon = sprite;
        q.face = face;
        q.tintIndex = tintIndex;
        q.guiLight = "front";
        // Force opaque alpha: side faces are solid-color filled in a second untextured
        // pass
        // 侧面强制不透明：由第二遍无纹理渲染以纯色填充，避免半透明纹素被 blend 冲淡
        q.solidColor = pixelARGB | 0xFF000000;

        // 顶点绕序：对标 BlockJsonModelBake.emitFaceFromCorners
        // EAST: v0(idx=111)=MAX_Y,MAX_Z v1(idx=101)=MIN_Y,MAX_Z v2(idx=100)=MIN_Y,MIN_Z
        // v3(idx=110)=MAX_Y,MIN_Z
        // WEST: v0(idx=010)=MAX_Y,MIN_Z v1(idx=000)=MIN_Y,MIN_Z v2(idx=001)=MIN_Y,MAX_Z
        // v3(idx=011)=MAX_Y,MAX_Z
        float minZ = MIN_Z / 16.0F, maxZ = MAX_Z / 16.0F;
        if (isLeft) {
            // WEST face (LEFT edge, outward -X)
            q.vertices[0] = new Vector3d(worldX, worldY1, minZ);
            q.vertices[1] = new Vector3d(worldX, worldY0, minZ);
            q.vertices[2] = new Vector3d(worldX, worldY0, maxZ);
            q.vertices[3] = new Vector3d(worldX, worldY1, maxZ);
        } else {
            // EAST face (RIGHT edge, outward +X)
            q.vertices[0] = new Vector3d(worldX, worldY1, maxZ);
            q.vertices[1] = new Vector3d(worldX, worldY0, maxZ);
            q.vertices[2] = new Vector3d(worldX, worldY0, minZ);
            q.vertices[3] = new Vector3d(worldX, worldY1, minZ);
        }
        // UV 按顶点分配：V 沿 Y 轴（v0→MAX_Y(top) 顶点, v1→MIN_Y(bottom) 顶点）；
        // U 沿 Z 轴跨越像素宽度（u0→MIN_Z, u1→MAX_Z，与 bakeHorizontalEdge 的 v0→MIN_Z 约定同构，
        // 对标 26.1.2 bakeSideFaces 垂直边缘同样给出 u0→u1 完整跨度）。
        // Full u0→u1 span across the Z-depth axis, matching vanilla 26.1.2 side-face
        // UVs.
        if (isLeft) {
            // WEST: 顶点 0/1 在 MIN_Z，顶点 2/3 在 MAX_Z
            q.up[0] = u0;
            q.vp[0] = v0;
            q.up[1] = u0;
            q.vp[1] = v1;
            q.up[2] = u1;
            q.vp[2] = v1;
            q.up[3] = u1;
            q.vp[3] = v0;
        } else {
            // EAST: 顶点 0/1 在 MAX_Z，顶点 2/3 在 MIN_Z
            q.up[0] = u1;
            q.vp[0] = v0;
            q.up[1] = u1;
            q.vp[1] = v1;
            q.up[2] = u0;
            q.vp[2] = v1;
            q.up[3] = u0;
            q.vp[3] = v0;
        }

        q.faceNormal = faceNormal(face);
        quads.add(q);
    }

    /**
     * 检查扁平像素数组中 (x,y) 是否透明（超出边界视为透明）。
     * getFrameTextureData(0) 返回 mipmap 层级数组，level 0 是 width*height 扁平数组。
     */
    private static boolean isTransparent(int[] flatPixels, int x, int y, int width) {
        if (x < 0 || y < 0 || x >= width) {
            return true;
        }
        int idx = y * width + x;
        if (idx < 0 || idx >= flatPixels.length) {
            return true;
        }
        return (flatPixels[idx] >> 24 & 0xFF) == 0;
    }

    private static Vector3d faceNormal(Direction face) {
        return face.getNormalVec3d();
    }
}
