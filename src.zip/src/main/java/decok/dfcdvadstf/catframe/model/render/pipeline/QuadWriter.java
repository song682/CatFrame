package decok.dfcdvadstf.catframe.model.render.pipeline;

import decok.dfcdvadstf.catframe.core.Direction;
import decok.dfcdvadstf.catframe.model.VanillaTextureTracker;
import decok.dfcdvadstf.catframe.model.core.baking.JsonModelBake.BakedQuad;
import decok.dfcdvadstf.catframe.model.render.ModelRenderRegistry;
import decok.dfcdvadstf.catframe.model.render.api.RenderContext;
import decok.dfcdvadstf.catframe.model.render.api.RenderPhase;
import decok.dfcdvadstf.catframe.model.render.extension.ao.light.CardinalLighting;
import decok.dfcdvadstf.catframe.resources.atlas.CatSprite;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;

import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import java.util.List;

/**
 * 顶点写入器：把原 {@code UniformRenderPipeline} 中"逐顶点写 Tessellator 的循环体"
 * 抽取为可复用的纯写入静态方法，对标原版 26w+ 管线中的 {@code QuadWriter}。
 * <p>
 * <b>职责边界（严格）</b>：本类<em>只写顶点</em> —— 运行扩展链
 * （{@link ModelRenderRegistry#apply(RenderContext)}）、计算亮度/颜色/UV、执行旋转与
 * display/preTransform 向量变换、调用 {@code t.addVertexWithUV}。
 * <b>不</b>做 {@code startDrawingQuads}/{@code draw}、<b>不</b>改 GL 状态、<b>不</b>绑纹理、
 * <b>不</b>调用 {@code applyBeforePart}/{@code applyAfterPart}（这些生命周期由
 * {@link FeatureRenderDispatcher} 按提交项管理）。
 * <p>
 * 逐顶点逻辑与原 {@code UniformRenderPipeline} 保持逐行一致，确保零渲染回归。
 */
public final class QuadWriter {

    private QuadWriter() {
    }

    /**
     * 写入方块 quads（世界 / 破坏贴图）。迁移自原 {@code renderBlockQuads} 的 for-quad 循环。
     *
     * @return 是否写入了任何顶点（供调用方决定是否 {@code t.draw()}）
     */
    public static boolean writeBlockQuads(RenderSubmit s, Tessellator t) {
        List<BakedQuad> allQuads = s.part.getAllQuads();

        double a = Math.toRadians(s.rotationDeg);
        double cos = Math.cos(a), sin = Math.sin(a);
        Point3d tmpVec = new Point3d();

        boolean hasVertices = false;
        for (BakedQuad q : allQuads) {
            int baseBrightness = s.world != null
                    ? s.block.getMixedBrightnessForBlock(s.world, s.x, s.y, s.z) : 0;
            // 方向阴影：按面方向取 CardinalLighting 系数。
            float baseShade = CardinalLighting.DEFAULT.byFace(q.face);

            // 创建上下文并运行扩展链
            RenderContext ctx = new RenderContext(s.phase, q,
                    s.world, s.x, s.y, s.z, s.block, null, baseBrightness, baseShade);
            ctx.metadata = s.metadata;
            ModelRenderRegistry.apply(ctx);
            if (ctx.skip)
                continue;
            hasVertices = true;

            // 提交到 Tessellator
            boolean hasVertexAO = ctx.aoBrightness[0] >= 0;

            if (hasVertexAO) {
                for (int i = 0; i < 4; i++) {
                    t.setBrightness(ctx.aoBrightness[i]);
                    float cr = ((ctx.color >> 16) & 0xFF) / 255.0f * ctx.shade * ctx.aoColorMul[i];
                    float cg = ((ctx.color >> 8) & 0xFF) / 255.0f * ctx.shade * ctx.aoColorMul[i];
                    float cb = (ctx.color & 0xFF) / 255.0f * ctx.shade * ctx.aoColorMul[i];
                    t.setColorOpaque_F(cr, cg, cb);

                    double vx = q.vx(i), vy = q.vy(i), vz = q.vz(i);
                    if (s.rotationDeg != 0) {
                        double px = vx - 0.5, pz = vz - 0.5;
                        vx = px * cos - pz * sin + 0.5;
                        vz = px * sin + pz * cos + 0.5;
                    }
                    // 应用 display transform（方块阶段扩展链默认不设置，null 检查兜底）
                    if (ctx.displayTransform != null) {
                        tmpVec.set(vx, vy, vz);
                        ctx.displayTransform.transform(tmpVec);
                        vx = tmpVec.x;
                        vy = tmpVec.y;
                        vz = tmpVec.z;
                    }
                    IIcon icon = resolveWorldIcon((ctx.iconOverride != null) ? ctx.iconOverride : q.icon);
                    double U = icon.getInterpolatedU(q.up[i]);
                    double V = icon.getInterpolatedV(q.vp[i]);
                    t.addVertexWithUV(s.x + vx, s.y + vy, s.z + vz, U, V);
                }
            } else {
                t.setBrightness(ctx.effectiveBrightness());
                float cr = ((ctx.color >> 16) & 0xFF) / 255.0f * ctx.shade;
                float cg = ((ctx.color >> 8) & 0xFF) / 255.0f * ctx.shade;
                float cb = (ctx.color & 0xFF) / 255.0f * ctx.shade;
                t.setColorOpaque_F(cr, cg, cb);

                IIcon icon = resolveWorldIcon((ctx.iconOverride != null) ? ctx.iconOverride : q.icon);
                for (int i = 0; i < 4; i++) {
                    double vx = q.vx(i), vy = q.vy(i), vz = q.vz(i);
                    if (s.rotationDeg != 0) {
                        double px = vx - 0.5, pz = vz - 0.5;
                        vx = px * cos - pz * sin + 0.5;
                        vz = px * sin + pz * cos + 0.5;
                    }
                    // 应用 display transform（方块阶段扩展链默认不设置，null 检查兜底）
                    if (ctx.displayTransform != null) {
                        tmpVec.set(vx, vy, vz);
                        ctx.displayTransform.transform(tmpVec);
                        vx = tmpVec.x;
                        vy = tmpVec.y;
                        vz = tmpVec.z;
                    }
                    double U, V;
                    if (s.phase == RenderPhase.BLOCK_DESTROY) {
                        // 破坏贴图 UV = 方块空间位置投影（复刻 1.7.10 renderFace* 的
                        // renderMin/Max*16 语义）：按面法向选择切向轴，旋转后顶点局部坐标 ×16
                        // 插值 → 贴图钉在几何上、绕方块一周连续（对齐 26.1.2 贴花语义）。
                        // 垂直面 V 取 16 - y*16（原版顶部顶点 y=maxY → V(0)，底部 → V(16)），
                        // 否则上下颠倒；NORTH/EAST 的 U 反向取 16 - x*16 / 16 - z*16，
                        // 使贴图沿南→东→北→西环绕时 U 连续（贴纸环绕语义）。
                        // Destroy decal UVs: block-space position projection, mimicking the
                        // vanilla renderMin/Max*16 semantics; the decal is pinned to the
                        // geometry and wraps continuously around the four vertical faces.
                        // Vertical faces use V = 16 - y*16 (vanilla binds V(0) to the top
                        // edge), and NORTH/EAST flip U so the texture wraps seamlessly
                        // around the block perimeter.
                        Direction f = q.face;
                        if (f == Direction.DOWN || f == Direction.UP) {
                            U = icon.getInterpolatedU(vx * 16.0);
                            V = icon.getInterpolatedV(vz * 16.0);
                        } else if (f == Direction.NORTH) {
                            U = icon.getInterpolatedU(16.0 - vx * 16.0);
                            V = icon.getInterpolatedV(16.0 - vy * 16.0);
                        } else if (f == Direction.SOUTH) {
                            U = icon.getInterpolatedU(vx * 16.0);
                            V = icon.getInterpolatedV(16.0 - vy * 16.0);
                        } else if (f == Direction.WEST) {
                            U = icon.getInterpolatedU(vz * 16.0);
                            V = icon.getInterpolatedV(16.0 - vy * 16.0);
                        } else if (f == Direction.EAST) {
                            U = icon.getInterpolatedU(16.0 - vz * 16.0);
                            V = icon.getInterpolatedV(16.0 - vy * 16.0);
                        } else {
                            // face 为 null（cross 等无向 quad）兜底回退模型 UV
                            // Fall back to baked model UVs for direction-less quads
                            U = icon.getInterpolatedU(q.up[i]);
                            V = icon.getInterpolatedV(q.vp[i]);
                        }
                    } else {
                        U = icon.getInterpolatedU(q.up[i]);
                        V = icon.getInterpolatedV(q.vp[i]);
                    }
                    t.addVertexWithUV(s.x + vx, s.y + vy, s.z + vz, U, V);
                }
            }
        }
        return hasVertices;
    }

    /**
     * 世界渲染的 icon 解析：CatSprite（CatAtlas 空间 UV）换回对应 vanilla sprite
     * （原版图集空间 UV）。世界渲染（BLOCK_WORLD/BLOCK_DESTROY）走 flushInline 写入
     * vanilla chunk Tessellator，批次绑定 vanilla blocks 图集（chunk 混批约束下无法
     * 换绑 CatAtlas），若 quad 携带 CatSprite UV 会在原版图集上采样错位 → 模糊/空白。
     * 查表无对应项（脏键等）时原样返回 CatSprite 兜底。
     * <p>
     * World rendering binds the vanilla blocks atlas (mixed batches make an atlas
     * swap impossible), so CatSprite UVs are remapped to the vanilla sprite space
     * through the snapshot table; unmatched keys fall back to the CatSprite.
     */
    private static IIcon resolveWorldIcon(IIcon icon) {
        if (icon instanceof CatSprite) {
            IIcon vanilla = VanillaTextureTracker.getVanillaIcons()
                    .get(((CatSprite) icon).getTexturePath());
            if (vanilla != null) {
                return vanilla;
            }
        }
        return icon;
    }

    /**
     * 写入物品 quads（GUI / 手持 / 掉落 / 展示框）。迁移自原 {@code renderItemQuads} 的 for-quad 循环。
     * <p>
     * {@code solidColor != 0} 的 quad（侧面纯色 quad）在本方法中<b>跳过</b>，
     * 由 {@link #writeSolidColorQuads(RenderSubmit, Tessellator)} 在独立的无纹理 draw call
     * 中渲染：
     * 侧面 quad 的 UV 紧贴“不透明→透明”边界，双线性 / mipmap 采样会混入透明邻居纹素，
     * 且 GL_MODULATE 会将纹素 alpha 乘入片段，导致窄面渲染为透明。
     *
     * @return {@code true} 若存在被跳过的 solidColor quad（调用方需执行第二遍无纹理渲染）
     */
    public static boolean writeItemQuads(RenderSubmit s, Tessellator t) {
        List<BakedQuad> allQuads = s.part.getAllQuads();
        boolean gui = (s.phase == RenderPhase.ITEM_GUI);
        // [方案B] 非 GUI 且非手持物品阶段（掉落 / 展示框）保留 GL_LIGHTING，
        // 改用逐面法线让 GL 计算方向光照，不再把 CardinalLighting 方向阴影烘焙进顶点色，
        // 避免“烘焙阴影 + GL 光照”双重着色导致的视角相关 bug。
        // GUI 与手持阶段均维持烘焙阴影：手持阶段不启用 GL_LIGHTING（避免双重着色），
        // 但亮度（lightmap）取玩家位置的世界光照（见 handBrightness），
        // 完全无外部光照时物品渲染为全黑，对标 1.7.10 ItemRenderer 的手持亮度语义。
        boolean glLit = !gui && !s.phase.isHandPhase();
        Matrix4d preTransform = s.preTransform;
        // 物品模型渲染变换（items JSON transformation 标签）：永远在 display 变换之后应用
        // Per-model item transformation: always applied after the display transform
        Matrix4d transformation = s.transformation;
        Point3d tmpVec = new Point3d();
        Vector3d tmpNormal = glLit ? new Vector3d() : null;

        // 手持阶段亮度取玩家位置世界光照（无光时全黑），其余非 GUI 阶段保持全亮
        int baseBrightness = gui ? 255 : (s.phase.isHandPhase() ? handBrightness() : 15728880);
        boolean hasSolidColor = false;

        for (BakedQuad q : allQuads) {
            // solidColor quad 跳过，留给 writeSolidColorQuads 无纹理渲染
            // Skip solid-color side quads: rendered in a separate untextured pass
            if (q.solidColor != 0) {
                hasSolidColor = true;
                continue;
            }

            // 方向阴影：GUI 按面方向烘焙 CardinalLighting 系数；
            // 非 GUI 交由 GL_LIGHTING 依逐面法线计算，baseShade 取 1.0 以免双重着色。
            float baseShade = glLit ? 1.0f : CardinalLighting.DEFAULT.byFace(q.face);
            RenderContext ctx = new RenderContext(s.phase, q,
                    s.world, s.x, s.y, s.z, s.block, s.stack, baseBrightness, baseShade);
            ModelRenderRegistry.apply(ctx);
            if (ctx.skip)
                continue;

            // GUI 阶段屏幕空间光照：方块类模型（gui_light="side"/null）按旋转后的
            // 法线方向着色，明暗固定在屏幕上（顶 1.0 / 左 0.8 / 右 0.6 / 底 0.5），
            // 不随 display.gui.rotation 变化；gui_light="front" 的 2D 物品保持全亮。
            if (gui && !"front".equals(ctx.quad.guiLight) && ctx.displayTransform != null) {
                ctx.shade = guiScreenShade(q, ctx.displayTransform);
            }

            // 非 GUI 阶段：发送逐面法线（随 display / transformation / preTransform 旋转），供 GL_LIGHTING
            // 使用。
            if (glLit) {
                writeQuadNormal(t, q, ctx.displayTransform, transformation, preTransform, tmpNormal);
            }

            t.setBrightness(ctx.effectiveBrightness());
            float cr = ((ctx.color >> 16) & 0xFF) / 255.0f * ctx.shade;
            float cg = ((ctx.color >> 8) & 0xFF) / 255.0f * ctx.shade;
            float cb = (ctx.color & 0xFF) / 255.0f * ctx.shade;
            if (gui) {
                t.setColorRGBA_F(cr, cg, cb, 1.0f);
            } else {
                t.setColorOpaque_F(cr, cg, cb);
            }

            IIcon icon = (ctx.iconOverride != null) ? ctx.iconOverride : q.icon;
            for (int i = 0; i < 4; i++) {
                double U = icon.getInterpolatedU(q.up[i]);
                double V = icon.getInterpolatedV(q.vp[i]);

                // 向量空间变换：先应用 display transform，再应用 transformation（items JSON
                // 的物品模型渲染变换，永远在 display 之后），最后应用 preTransform
                // 顶点变换顺序：v' = M_pre × M_transformation × M_display × v
                tmpVec.set(q.vx(i), q.vy(i), q.vz(i));
                if (ctx.displayTransform != null) {
                    ctx.displayTransform.transform(tmpVec);
                }
                if (transformation != null) {
                    transformation.transform(tmpVec);
                }
                if (preTransform != null) {
                    preTransform.transform(tmpVec);
                }
                t.addVertexWithUV(tmpVec.x, tmpVec.y, tmpVec.z, U, V);
            }
        }
        return hasSolidColor;
    }

    /**
     * 写入 solidColor quad（侧面纯色 quad）—— 纯顶点色渲染，<b>调用方必须先禁用纹理</b>。
     * <p>
     * 对标 26.1.2 {@code ItemModelGenerator} 侧面渲染语义：侧面使用边缘像素的 RGB
     * 作为不透明纯色填充，不受纹理 alpha 影响。1.7.10 固定管线下，{@code GL_MODULATE}
     * 会把半透明纹素 alpha 乘入最终片段，导致半透明纹理的侧面消失；禁用纹理后 fragment
     * 颜色完全由顶点色决定，alpha 恒为 1.0。
     * <p>
     * <b>职责边界</b>：本方法只写顶点，不做 {@code glDisable(GL_TEXTURE_2D)} 等 GL
     * 状态管理（由 {@link FeatureRenderDispatcher} 负责）。
     */
    public static void writeSolidColorQuads(RenderSubmit s, Tessellator t) {
        List<BakedQuad> allQuads = s.part.getAllQuads();
        boolean gui = (s.phase == RenderPhase.ITEM_GUI);
        // 与 writeItemQuads 一致：手持阶段不应用 GL_LIGHTING，走烘焙阴影分支
        boolean glLit = !gui && !s.phase.isHandPhase();
        Matrix4d preTransform = s.preTransform;
        Matrix4d transformation = s.transformation;
        Point3d tmpVec = new Point3d();
        Vector3d tmpNormal = glLit ? new Vector3d() : null;

        // 手持阶段亮度取玩家位置世界光照（无光时全黑），其余非 GUI 阶段保持全亮
        int baseBrightness = gui ? 255 : (s.phase.isHandPhase() ? handBrightness() : 15728880);

        for (BakedQuad q : allQuads) {
            if (q.solidColor == 0)
                continue;

            float baseShade = glLit ? 1.0f : CardinalLighting.DEFAULT.byFace(q.face);
            RenderContext ctx = new RenderContext(s.phase, q,
                    s.world, s.x, s.y, s.z, s.block, s.stack, baseBrightness, baseShade);
            ModelRenderRegistry.apply(ctx);
            if (ctx.skip)
                continue;

            // GUI 阶段屏幕空间光照：与 writeItemQuads 一致的屏幕空间方向着色
            if (gui && !"front".equals(ctx.quad.guiLight) && ctx.displayTransform != null) {
                ctx.shade = guiScreenShade(q, ctx.displayTransform);
            }

            // 非 GUI 阶段：发送逐面法线（随 display / transformation / preTransform 旋转），供 GL_LIGHTING
            // 使用。
            if (glLit) {
                writeQuadNormal(t, q, ctx.displayTransform, transformation, preTransform, tmpNormal);
            }

            t.setBrightness(ctx.effectiveBrightness());
            // 使用 solidColor 的 RGB，alpha 固定 1.0（侧面恒不透明）
            // 颜色再乘 ctx.color（tint 扩展注入）：与 writeItemQuads 正面渲染对齐，
            // 避免 grass 等 tint 物品的侧面挤出显示未染色的原始纹理色（颜色失调）
            // Multiply by ctx.color (tint) to match the front-face pass, so tinted
            // items (e.g. grass) no longer show raw un-tinted side extrusions.
            float cr = ((q.solidColor >> 16) & 0xFF) / 255.0f * ((ctx.color >> 16) & 0xFF) / 255.0f * ctx.shade;
            float cg = ((q.solidColor >> 8) & 0xFF) / 255.0f * ((ctx.color >> 8) & 0xFF) / 255.0f * ctx.shade;
            float cb = (q.solidColor & 0xFF) / 255.0f * (ctx.color & 0xFF) / 255.0f * ctx.shade;
            t.setColorRGBA_F(cr, cg, cb, 1.0f);

            for (int i = 0; i < 4; i++) {
                // 顶点变换顺序与 writeItemQuads 一致：v' = M_pre × M_transformation × M_display × v
                tmpVec.set(q.vx(i), q.vy(i), q.vz(i));
                if (ctx.displayTransform != null) {
                    ctx.displayTransform.transform(tmpVec);
                }
                if (transformation != null) {
                    transformation.transform(tmpVec);
                }
                if (preTransform != null) {
                    preTransform.transform(tmpVec);
                }
                // 无纹理时 UV 被忽略，但 addVertexWithUV 是 Tessellator 唯一的提交 API
                t.addVertexWithUV(tmpVec.x, tmpVec.y, tmpVec.z, 0, 0);
            }
        }
    }

    /**
     * 写入附魔光效（glint）quads —— 重放提交项的<b>纹理</b>几何（跳过 solidColor 侧面），
     * 供 {@code GuiGraphicsExtractor.renderEnchantmentGlint} 以 glint 纹理 +
     * 滚动纹理矩阵叠加绘制。
     * Write enchantment glint quads: replays the textured geometry (skipping
     * solid-color side quads) so the glint follows the opaque texel contour,
     * for the glint overlay passes.
     * <p>
     * 与 {@link #writeItemQuads} 的差异：
     * <ul>
     * <li><b>跳过</b> {@code solidColor != 0} 的 quad —— 侧面深度由正常 pass 第二遍
     * 无纹理渲染以强制不透明 alpha 写入（无 alpha 裁剪），重放会使光效在侧面投影
     * 覆盖的透明像素上出现（溢出）；光效只需贴合正常 pass 第一遍经 alpha test
     * 裁剪后写入深度的纹理轮廓，对标原版 1.7.10 光效语义；</li>
     * <li>颜色强制为 glint 紫（对标原版 {@code RenderItem.renderEffect} 的
     * {@code (0.5, 0.25, 0.8)}；非 GUI 阶段对标 1.7.10 {@code ItemRenderer}
     * 手持光效乘 0.76）；</li>
     * <li>不写法线 —— 光效 pass 已关闭 {@code GL_LIGHTING}；</li>
     * <li>UV 仍取烘焙图集 UV，流纹跨度由光效 pass 的纹理矩阵 scale 控制。</li>
     * </ul>
     * 顶点变换链与 {@link #writeItemQuads} <b>逐位一致</b>
     * （v' = M_pre × M_transformation × M_display × v），且运行同一扩展链尊重
     * {@code ctx.skip}，保证重放几何与正常 pass 完全重合，通过 {@code GL_EQUAL} 深度测试。
     * <p>
     * <b>调用前提</b>：必须在 {@code applyBeforePart} 状态仍有效期间调用
     * （display 矩阵等 beforePart 状态才能重算一致）。
     */
    public static void writeGlintQuads(RenderSubmit s, Tessellator t) {
        List<BakedQuad> allQuads = s.part.getAllQuads();
        boolean gui = (s.phase == RenderPhase.ITEM_GUI);
        Matrix4d preTransform = s.preTransform;
        Matrix4d transformation = s.transformation;
        Point3d tmpVec = new Point3d();

        int baseBrightness = gui ? 255 : 15728880;
        // glint 紫：GUI 对标 RenderItem.renderEffect (0.5, 0.25, 0.8)；
        // 非 GUI 对标 1.7.10 ItemRenderer 手持光效（同色乘 0.76）
        // Glint purple: GUI matches RenderItem.renderEffect; non-GUI multiplied by 0.76
        float k = gui ? 1.0f : 0.76f;
        float gr = 0.5f * k, gg = 0.25f * k, gb = 0.8f * k;

        for (BakedQuad q : allQuads) {
            // 跳过 solidColor 侧面 quad：正常 pass 中侧面在第二遍无纹理渲染以强制
            // 不透明 alpha 写入深度（无 alpha 裁剪），重放会使 GL_EQUAL 光效渲染在
            // 侧面投影覆盖的透明像素上（手持旋转视角下侧面投影偏离正面轮廓，溢出明显）。
            // 跳过使光效严格贴合正常 pass 第一遍（alpha test 裁剪后）写入深度的
            // 不透明像素，保持与原版 1.7.10 相同的视觉行为。
            // Skip solid-color side quads: their depth is written by the second
            // untextured pass with forced-opaque alpha (no cutout), so replaying
            // them would paint glint over transparent texels wherever the side
            // projection overlaps them. Skipping confines glint to the opaque
            // texels that survived the normal pass's alpha test, matching vanilla.
            if (q.solidColor != 0) {
                continue;
            }

            // 运行扩展链：获取 displayTransform 并尊重 skip（与正常 pass 的可见性一致）
            // Run extension chain: obtain displayTransform and honor skip flag
            RenderContext ctx = new RenderContext(s.phase, q,
                    s.world, s.x, s.y, s.z, s.block, s.stack, baseBrightness, 1.0f);
            ModelRenderRegistry.apply(ctx);
            if (ctx.skip)
                continue;

            t.setBrightness(baseBrightness);
            t.setColorRGBA_F(gr, gg, gb, 1.0f);

            IIcon icon = (ctx.iconOverride != null) ? ctx.iconOverride : q.icon;
            for (int i = 0; i < 4; i++) {
                // solidColor quad 可能无 icon，UV 兜底为 0（流纹动画仍由纹理矩阵驱动）
                // solid-color quads may lack an icon; fall back to UV 0
                double U = (icon != null) ? icon.getInterpolatedU(q.up[i]) : 0.0;
                double V = (icon != null) ? icon.getInterpolatedV(q.vp[i]) : 0.0;

                // 顶点变换顺序与 writeItemQuads 一致：v' = M_pre × M_transformation × M_display × v
                tmpVec.set(q.vx(i), q.vy(i), q.vz(i));
                if (ctx.displayTransform != null) {
                    ctx.displayTransform.transform(tmpVec);
                }
                if (transformation != null) {
                    transformation.transform(tmpVec);
                }
                if (preTransform != null) {
                    preTransform.transform(tmpVec);
                }
                t.addVertexWithUV(tmpVec.x, tmpVec.y, tmpVec.z, U, V);
            }
        }
    }

    /**
     * [方案B] 计算 quad 的逐面法线并写入 Tessellator。
     * <p>
     * 法线取自 {@link BakedQuad#face} 的方向向量，依次经 display / transformation / preTransform
     * 的旋转部分变换（与软件变换后的顶点保持一致），归一化后调用 {@code t.setNormal}。
     * 长度由 {@code GL_NORMALIZE} 兜底（见 {@link FeatureRenderDispatcher}），故只需方向正确。
     */
    private static void writeQuadNormal(Tessellator t, BakedQuad q,
            Matrix4d displayTransform, Matrix4d transformation,
            Matrix4d preTransform, Vector3d tmp) {
        Direction face = q.face;
        if (face != null) {
            tmp.set(face.getStepX(), face.getStepY(), face.getStepZ());
        } else {
            tmp.set(0.0, 1.0, 0.0);
        }
        if (displayTransform != null)
            transformDirection(displayTransform, tmp);
        if (transformation != null)
            transformDirection(transformation, tmp);
        if (preTransform != null)
            transformDirection(preTransform, tmp);
        double len = tmp.length();
        if (len > 1.0e-6)
            tmp.scale(1.0 / len);
        t.setNormal((float) tmp.x, (float) tmp.y, (float) tmp.z);
    }

    /** 用 4x4 矩阵的 3x3 旋转部分变换方向向量（忽略平移）。 */
    private static void transformDirection(Matrix4d m, Vector3d v) {
        double x = m.m00 * v.x + m.m01 * v.y + m.m02 * v.z;
        double y = m.m10 * v.x + m.m11 * v.y + m.m12 * v.z;
        double z = m.m20 * v.x + m.m21 * v.y + m.m22 * v.z;
        v.set(x, y, z);
    }

    /**
     * 计算 GUI 阶段的屏幕空间方向光照（对标 1.7.10 {@code RenderItem} 方块分支的
     * 视觉语义）：光照方向固定在屏幕上——顶部 1.0、屏幕左侧 0.8、屏幕右侧 0.6、
     * 底部 0.5，不随 {@code display.gui.rotation} 的旋转角度变化。
     * <p>
     * 原理：将 quad 的模型空间面法线经 display 矩阵的旋转部分变换到世界/屏幕空间后，
     * 按旋转后法线的主导轴向查表。这保证无论 GUI 视角角度如何，明暗分布始终是
     * 「顶部最亮、下左面次之、下右面最暗」，避免模型空间 shade 随视角旋转导致的
     * 左右亮度颠倒。
     * <p>
     * 仅用于 {@code gui_light="side"}（或 null）的方块类模型；{@code gui_light="front"}
     * 的 2D 物品保持全亮（shade=1.0），不进入本方法。
     * <p>
     * Screen-space directional shading for GUI block models: the light is fixed
     * on screen (top 1.0 / screen-left 0.8 / screen-right 0.6 / bottom 0.5)
     * regardless of the display.gui.rotation angle.
     */
    private static float guiScreenShade(BakedQuad q, Matrix4d displayTransform) {
        // 模型空间面法线（轴对齐单位向量），face 为 null（cross 等无向面）时按 UP 处理
        double nx = 0, ny = 1, nz = 0;
        if (q.face != null) {
            nx = q.face.getStepX();
            ny = q.face.getStepY();
            nz = q.face.getStepZ();
        }
        // 经 display 矩阵旋转到屏幕/世界空间（忽略平移；GUI scale 通常均匀，
        // 非均匀缩放下的方向偏差可接受）
        if (displayTransform != null) {
            double x = displayTransform.m00 * nx + displayTransform.m01 * ny + displayTransform.m02 * nz;
            double y = displayTransform.m10 * nx + displayTransform.m11 * ny + displayTransform.m12 * nz;
            double z = displayTransform.m20 * nx + displayTransform.m21 * ny + displayTransform.m22 * nz;
            nx = x;
            ny = y;
            nz = z;
        }
        double ax = Math.abs(nx), ay = Math.abs(ny), az = Math.abs(nz);
        if (ay >= ax && ay >= az) return ny > 0 ? 1.0f : 0.5f; // 顶面最亮 / 底面最暗
        if (ax >= ay && ax >= az) return nx > 0 ? 0.6f : 0.8f; // 屏幕右侧暗 / 屏幕左侧亮
        return 0.8f; // 正对屏幕方向（南北面语义）
    }

    /**
     * 手持阶段的基础亮度：取玩家所在位置的世界光照（天空光 + 方块光），
     * 对标 1.7.10 {@code ItemRenderer.renderItemInFirstPerson} 的
     * {@code getLightBrightnessForSkyBlocks(玩家坐标, 0)} 语义——完全无外部
     * 光照时返回 0，手持物品渲染为全黑；玩家或世界上下文缺失时回退全亮兜底。
     * 返回值与 {@link Tessellator#setBrightness} 的 packed 格式一致（sky<<20 | block<<4）。
     * <p>
     * Base brightness for hand-held phases: world light sampled at the player's
     * position (same semantics as 1.7.10 {@code ItemRenderer}), so held items
     * render fully black when no external light is available.
     *
     * @return packed brightness（15728880 = 全亮，0 = 全黑）
     */
    private static int handBrightness() {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = (mc != null) ? mc.thePlayer : null;
        if (player == null || player.worldObj == null) {
            return 15728880;
        }
        return player.worldObj.getLightBrightnessForSkyBlocks(
                MathHelper.floor_double(player.posX),
                MathHelper.floor_double(player.posY),
                MathHelper.floor_double(player.posZ), 0);
    }
}
