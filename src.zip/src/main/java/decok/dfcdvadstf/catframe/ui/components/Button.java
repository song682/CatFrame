package decok.dfcdvadstf.catframe.ui.components;

import decok.dfcdvadstf.catframe.ui.GuiGraphicsExtractor;
import decok.dfcdvadstf.catframe.ui.Text;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

/**
 * <p>
 * Button component implementation.<br>
 * Counterpart of the high-version Minecraft {@code Button}.
 * </p>
 */
public class Button extends AbstractButton {

    /** Standard widths */
    public static final int SMALL_WIDTH = 120;
    public static final int DEFAULT_WIDTH = 150;
    public static final int BIG_WIDTH = 200;
    public static final int DEFAULT_HEIGHT = 20;

    private final OnPress onPress;

    protected Button(int x, int y, int width, int height, Text message, OnPress onPress) {
        this(x, y, width, height, message, onPress, false);
    }

    protected Button(int x, int y, int width, int height, Text message, OnPress onPress, boolean useVanillaTexture) {
        super(x, y, width, height, message);
        this.onPress = onPress;
        this.useVanillaTexture = useVanillaTexture;
    }

    /**
     * Creates a new Button builder.
     * <p>
     * 创建新的 Button 构建器。
     * </p>
     */
    public static Builder builder(Text message, OnPress onPress) {
        return new Builder(message, onPress);
    }

    @Override
    public void onPress() {
        if (onPress != null) {
            onPress.onPress(this);
        }
    }

    /**
     * 绘制按钮背景与居中文本 —— 可见性与悬停状态已由
     * {@link #extractRenderState} 在调用前处理。<br>
     * Draws the button background and centred text — visibility and hover
     * state are already handled by {@link #extractRenderState}.
     */
    @Override
    protected void renderWidget(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTicks) {
        renderBackground(graphics, mouseX, mouseY, partialTicks);

        // Draw the button text
        FontRenderer font = Minecraft.getMinecraft().fontRenderer;
        Text message = getMessage();
        String text = message != null ? message.getString() : "";
        int textColor;
        if (!active) {
            textColor = TEXT_COLOR_DISABLED;
        } else if (isHovered) {
            textColor = TEXT_COLOR_HOVER;
        } else {
            textColor = TEXT_COLOR_ENABLED;
        }

        int textX = x + (width - font.getStringWidth(text)) / 2;
        int textY = y + (height - font.FONT_HEIGHT) / 2;
        font.drawStringWithShadow(text, textX, textY, textColor);
    }

    // ──── OnPress callback ────

    @FunctionalInterface
    public interface OnPress {
        void onPress(Button button);
    }

    // ──── Builder ────

    /**
     * Builder for constructing a {@link Button}.
     * <p>
     * 用于构建 {@link Button} 的构建器。
     * </p>
     */
    public static class Builder {
        private final Text message;
        private final OnPress onPress;
        private int x;
        private int y;
        private int width = DEFAULT_WIDTH;
        private int height = DEFAULT_HEIGHT;
        private boolean useVanillaTexture = false;

        public Builder(Text message, OnPress onPress) {
            this.message = message;
            this.onPress = onPress;
        }

        public Builder pos(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public Builder width(int width) {
            this.width = width;
            return this;
        }

        public Builder height(int height) {
            this.height = height;
            return this;
        }

        public Builder useVanillaTexture(boolean useVanilla) {
            this.useVanillaTexture = useVanilla;
            return this;
        }

        public Button build() {
            return new Button(x, y, width, height, message, onPress, useVanillaTexture);
        }
    }
}
